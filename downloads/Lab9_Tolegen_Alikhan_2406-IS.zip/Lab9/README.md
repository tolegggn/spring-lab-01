# Laboratory 9 — IntelliJ IDEA project

Tolegen Alikhan · 2406-IS · Variant 2

## Open in IntelliJ IDEA
1. Extract this ZIP to a writable directory (for example Documents).
2. IntelliJ IDEA: File > Open > select this folder's pom.xml > Open as Project.
3. Select JDK 21 or 25 for Project SDK and Maven runner; use Download JDK if needed.
4. Wait for Maven dependency import to complete.
5. Open src/main/java/kz/iitu/lab9/Lab9Application.java and click the green Run button beside main().
6. Open http://localhost:8089/demo.html in the browser.

This ZIP is the standalone lab9 project, so its pom.xml is at the root.
It already includes Maven Wrapper. Root projects from earlier labs are not required.
For the first build, Internet access is required to download Maven and dependencies.

## PowerShell alternative (from this extracted folder)
.\mvnw.cmd clean verify
java -jar target/lab9-1.0.0.jar

## Linux/macOS alternative
bash mvnw clean verify
java -jar target/lab9-1.0.0.jar

## Tests in IntelliJ IDEA
Right-click src/test/java and select Run All Tests, or use Maven > Lifecycle > test.
There are 10 integration tests covering transactions, propagation, isolation, optimistic locking and migrations.

## Submission files
The English Word report is in docs/Lab9_Report_Tolegen_Alikhan_2406-IS.docx.
Six browser screenshots are in docs/screenshots/.
Original repository: https://github.com/tolegggn/spring-lab-01/tree/lab9/lab9

The default H2 database persists under data/ relative to the working directory.
Each submitted transfer changes balances. Restarting preserves the data.
